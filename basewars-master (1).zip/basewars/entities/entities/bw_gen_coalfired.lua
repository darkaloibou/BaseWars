AddCSLuaFile()

ENT.Base 			= "bw_base_generator"
ENT.PrintName 		= "Coal Fired Generator"

ENT.Model 			= "models/props_wasteland/laundry_washer003.mdl"

ENT.PowerGenerated 	= 19
ENT.PowerCapacity 	= 2000

ENT.TransmitRadius 	= 600
ENT.TransmitRate 	= 20
