AddCSLuaFile()
ENT.Base = "bw_base_moneyprinter"

ENT.Model = "models/props_lab/reciever01a.mdl"
ENT.Skin = 0

ENT.Capacity 		= 35000
ENT.PrintInterval 	= 1
ENT.PrintAmount		= 12

ENT.PrintName = "Silver Printer"

ENT.FontColor = Color(180, 180, 195)
ENT.BackColor = Color(32, 32, 32)

ENT.IsValidRaidable = false

ENT.PresetMaxHealth = 150
