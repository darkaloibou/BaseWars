AddCSLuaFile()
ENT.Base = "bw_base_moneyprinter"

ENT.Model = "models/props_lab/reciever01a.mdl"
ENT.Skin = 0

ENT.Capacity 		= 12000000
ENT.PrintInterval 	= 1
ENT.PrintAmount		= 2200

ENT.PrintName = "Dark Matter Printer"

ENT.FontColor = Color(50, 50, 50)
ENT.BackColor = color_black

ENT.IsValidRaidable = true

ENT.PresetMaxHealth = 900
