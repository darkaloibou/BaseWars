AddCSLuaFile()
ENT.Base = "bw_base_moneyprinter"

ENT.Model = "models/props_lab/reciever01a.mdl"
ENT.Skin = 0

ENT.Capacity 		= 24000000
ENT.PrintInterval 	= 1
ENT.PrintAmount		= 6200

ENT.PrintName = "Monolith Printer"

ENT.FontColor = Color(51, 102, 255)
ENT.BackColor = color_black

ENT.IsValidRaidable = true
ENT.PresetMaxHealth = 2000
