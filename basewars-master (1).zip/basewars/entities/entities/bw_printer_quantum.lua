AddCSLuaFile()
ENT.Base = "bw_base_moneyprinter"

ENT.Model = "models/props_lab/reciever01a.mdl"
ENT.Skin = 0

ENT.Capacity 		= 30000000
ENT.PrintInterval 	= 1
ENT.PrintAmount		= 10250

ENT.PrintName = "Quantum Printer"

ENT.FontColor = Color(50, 90, 220)
ENT.BackColor = color_white

ENT.IsValidRaidable = true
ENT.PresetMaxHealth = 3000
