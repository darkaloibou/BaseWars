AddCSLuaFile()
ENT.Base = "bw_base_moneyprinter"

ENT.Model = "models/props_lab/reciever01a.mdl"
ENT.Skin = 0

ENT.Capacity 		= 180000
ENT.PrintInterval 	= 1
ENT.PrintAmount		= 24

ENT.PrintName = "Platinum Printer"

ENT.FontColor = Color(229, 228, 226)
ENT.BackColor = Color(79, 78, 76)

ENT.IsValidRaidable = true

ENT.PresetMaxHealth = 350
