AddCSLuaFile()

ENT.Base 			= "bw_base_generator"
ENT.PrintName 		= "Fission Reactor"

ENT.Model 			= "models/props/de_nuke/equipment1.mdl"

ENT.PowerGenerated 	= 31
ENT.PowerCapacity 	= 3000

ENT.TransmitRadius 	= 600
ENT.TransmitRate 	= 25
