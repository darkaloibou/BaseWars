AddCSLuaFile()
ENT.Base = "bw_base_moneyprinter"

ENT.Model = "models/props_lab/reciever01a.mdl"
ENT.Skin = 0

ENT.Capacity 		= 15000
ENT.PrintInterval 	= 1
ENT.PrintAmount		= 6

ENT.PrintName = "Copper Printer"

ENT.FontColor = Color(200, 117, 51)
ENT.BackColor = color_black

ENT.IsValidRaidable = false
