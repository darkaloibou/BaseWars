AddCSLuaFile()

ENT.Base 			= "bw_base_generator"
ENT.PrintName 		= "Solar Panel"

ENT.Model 			= "models/props_lab/miniteleport.mdl"

ENT.PowerGenerated 	= 13
ENT.PowerCapacity 	= 300

ENT.TransmitRadius 	= 200
ENT.TransmitRate 	= 7
