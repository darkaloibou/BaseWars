AddCSLuaFile()

ENT.Base 			= "bw_base_generator"
ENT.PrintName 		= "Fusion Reactor"

ENT.Model 			= "models/xqm/hydcontrolbox.mdl"

ENT.PowerGenerated 	= 150
ENT.PowerCapacity 	= 50000

ENT.TransmitRadius 	= 700
ENT.TransmitRate 	= 35
