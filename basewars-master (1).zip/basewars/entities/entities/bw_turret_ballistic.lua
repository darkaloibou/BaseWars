AddCSLuaFile()

ENT.Base = "bw_base_turret"
ENT.Type = "anim"
 
ENT.PrintName = "Ballistic Turret"
ENT.Model = "models/Combine_turrets/Floor_turret.mdl"
 
ENT.PowerRequired = 10
ENT.PowerMin = 1000
ENT.PowerCapacity = 2500
 
ENT.Drain = 35
 
ENT.Damage = 6
ENT.Radius = 750
ENT.ShootingDelay = 0.1
ENT.Ammo = -1
 