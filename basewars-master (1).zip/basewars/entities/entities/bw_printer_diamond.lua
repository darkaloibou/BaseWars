AddCSLuaFile()
ENT.Base = "bw_base_moneyprinter"

ENT.Model = "models/props_lab/reciever01a.mdl"
ENT.Skin = 0

ENT.Capacity 		= 250000
ENT.PrintInterval 	= 1
ENT.PrintAmount		= 32

ENT.PrintName = "Diamond Printer"

ENT.FontColor = Color(185, 242, 255)
ENT.BackColor = Color(69, 68, 96)

ENT.IsValidRaidable = true

ENT.PresetMaxHealth = 500
