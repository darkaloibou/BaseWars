AddCSLuaFile()
ENT.Base = "bw_base_moneyprinter"

ENT.Model = "models/props_lab/reciever01a.mdl"
ENT.Skin = 0

ENT.Capacity 		= 500000
ENT.PrintInterval 	= 1
ENT.PrintAmount		= 48

ENT.PrintName = "Nuclear Printer"

ENT.FontColor = Color(0, 255, 0)
ENT.BackColor = color_black

ENT.IsValidRaidable = true

ENT.PresetMaxHealth = 650
