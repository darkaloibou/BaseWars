AddCSLuaFile()
ENT.Base = "bw_base_moneyprinter"

ENT.Model = "models/props_lab/reciever01a.mdl"
ENT.Skin = 0

ENT.Capacity 		= 6000000
ENT.PrintInterval 	= 1
ENT.PrintAmount		= 1325

ENT.PrintName = "Mobius Printer"

ENT.FontColor = Color(255, 0, 255)
ENT.BackColor = color_black

ENT.IsValidRaidable = true

ENT.PresetMaxHealth = 850
