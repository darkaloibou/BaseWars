#To-do

###High
- [ ] Auto-sell on disconnect (10 minutes after disconnecting to allow player crashes)
- [ ] Visual
    - [x] Fix Interaction HUD (it only looks okay after a reload of the script... what?)
    - [ ] Set correct holdtypes on Twitch SWEPs
    
---
####Normal
- [x] Visual
    - [x] Clientside ConVar to toggle rank tags
- [x] Make it so hands are selected automatically on spawn
- [ ] Fix Team chat (simply doesn't work)

---
#####Low
- [ ] Visual
    - [ ] Make the electronics HUD match the general HUD's design
    - [ ] Make QChat match the general HUD's design
    - [ ] Make Twitch SWEPs Free-Aim look correct with CS:S viewmodels
    - [ ] Make a custom weapon selection HUD matching with the general HUD's design

---
####Unknown priority
- [ ] Quests / Positive karma (as requested as Q2F2, probably normal/high priority?)

---
######*Requests*
- [ ] Replace aowl with mingeban (Ask Q2F2? It has support for working with aowl.AddCommand commands, but no pre-made commands done yet)
- [ ] Replace current AFK system with Tenrys' (include AFKmera along?)
